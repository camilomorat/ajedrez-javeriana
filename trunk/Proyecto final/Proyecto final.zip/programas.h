#ifndef PROGRAMAS_H
#define PROGRAMAS_H

const TAM=8;

void imprimirTablero(arreglo[TAM][TAM]);

int cambio(char numero);

struct Ficha
{
       int color;
       int tipo;
       int movimiento;
} 

#endif
