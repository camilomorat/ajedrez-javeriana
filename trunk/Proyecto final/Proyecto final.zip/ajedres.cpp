#include <cstdlib>
#include <iostream>
#include "programas.h"

using namespace std;


int main(int argc, char *argv[])
{
    char jugada[3];
    int ajedrez[8][8];
   
    cout<<endl;         
    cout<<"Recuerde colocar en mayusculas las letras y sin espacios\n";        
    cout<<"Digite la jugada: \n";
    cin>>jugada;
         
         //if((jugada[0]=='F')&&(jugada[1]=='I')&&(jugada[2]=='N'))
         
   

    system("PAUSE");
    return EXIT_SUCCESS;
}
